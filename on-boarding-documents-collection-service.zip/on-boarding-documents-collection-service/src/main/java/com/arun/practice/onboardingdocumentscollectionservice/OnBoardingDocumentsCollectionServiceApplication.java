package com.arun.practice.onboardingdocumentscollectionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnBoardingDocumentsCollectionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnBoardingDocumentsCollectionServiceApplication.class, args);
	}

}

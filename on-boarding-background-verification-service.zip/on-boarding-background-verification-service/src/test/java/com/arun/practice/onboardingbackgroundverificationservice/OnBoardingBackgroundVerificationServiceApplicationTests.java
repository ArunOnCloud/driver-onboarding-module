package com.arun.practice.onboardingbackgroundverificationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnBoardingBackgroundVerificationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.arun.practice.onboardingbackgroundverificationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnBoardingBackgroundVerificationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnBoardingBackgroundVerificationServiceApplication.class, args);
	}

}

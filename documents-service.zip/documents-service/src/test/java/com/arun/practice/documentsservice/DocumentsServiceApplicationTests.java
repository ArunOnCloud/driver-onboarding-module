package com.arun.practice.documentsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DocumentsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

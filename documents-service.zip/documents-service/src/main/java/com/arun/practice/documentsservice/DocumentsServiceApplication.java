package com.arun.practice.documentsservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DocumentsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DocumentsServiceApplication.class, args);
	}

}

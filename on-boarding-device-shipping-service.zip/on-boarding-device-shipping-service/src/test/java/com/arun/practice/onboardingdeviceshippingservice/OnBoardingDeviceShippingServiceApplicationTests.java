package com.arun.practice.onboardingdeviceshippingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnBoardingDeviceShippingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}

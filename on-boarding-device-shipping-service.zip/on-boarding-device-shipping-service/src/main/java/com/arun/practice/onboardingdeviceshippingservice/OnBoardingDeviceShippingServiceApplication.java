package com.arun.practice.onboardingdeviceshippingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnBoardingDeviceShippingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnBoardingDeviceShippingServiceApplication.class, args);
	}

}
